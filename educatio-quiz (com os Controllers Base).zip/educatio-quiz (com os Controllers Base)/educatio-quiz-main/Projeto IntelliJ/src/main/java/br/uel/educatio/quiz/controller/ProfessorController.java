package br.uel.educatio.quiz.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.uel.educatio.quiz.model.Professor;
import br.uel.educatio.quiz.service.ProfessorService;
import br.uel.educatio.quiz.service.QuizService;
import jakarta.validation.Valid;




//Deve ser revisiada!!!


@RequestMapping("/professor")
public class ProfessorController {
    private final ProfessorService profService;
    private final QuizService quizService;

    
    public ProfessorController(ProfessorService professorService, QuizService quizService) {
        this.profService = professorService;
        this.quizService = quizService;    
    }

    @GetMapping("/listar")
    public String listarTodos (Model model){
        model.addAttribute("professores", profService.listarTodos());
        return "pageFictícia";
    }

    @GetMapping("/buscar")
    public String buscar (@RequestParam("id") long id_prof, Model model){
        model.addAttribute("professor", profService.buscarPorId(id_prof));
        return "pageFictícia";
    }

    @PostMapping("salvar")
    public String salvarProfessor(@Valid @ModelAttribute Professor prof, Model model, RedirectAttributes ra){
        try {
            profService.salvar(prof);
            ra.addFlashAttribute("mensagem", "Professor salvo!");
            return "ficticio"; //"form"
        } catch (RuntimeException e){
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/ficticio";
            /* Maneira que encontrei para burlar o problema de não mostrar o erro pelo
            Binding Results
            */
        }
    }

    @PatchMapping("/editar/{id}")
    public String atualizarPerfilProfessor(@PathVariable("id") long id, @Valid @ModelAttribute Professor prof_atualizado, Model model, RedirectAttributes ra) {
        try {
            profService.atualizarPerfilProfessor(id, prof_atualizado);
            ra.addFlashAttribute("mensagem", "Perfil Atualizado!");
            return "ficticio"; //"form"
        } catch (RuntimeException e){
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/ficticio";
            /* Maneira que encontrei para burlar o problema de não mostrar o erro pelo
            Binding Results
            */
        }
    } 
    
    @DeleteMapping("/{id}")
    public String deletarProfessor(@PathVariable("id") long id_prof, RedirectAttributes ra) {
        try {
            profService.deletarPorId(id_prof);
            ra.addFlashAttribute("mensagem", "Professor deletado com sucesso!");
            return "ficticio"; //"form"

        } catch (RuntimeException e){ //Ver se isso vai dar BO
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/ficticio";
            /* Maneira que encontrei para burlar o problema de não mostrar o erro pelo
            Binding Results
            */
        }
    }

    @PostMapping("/adicionarArea")
    public String adicionarArea(@RequestParam("id_area") long id_area, @RequestParam("id_prof") long id_prof, RedirectAttributes ra) {
        try {
            profService.adicionarAreaProfessor(id_area, id_prof);
            ra.addFlashAttribute("mensagem", "Área adicionada com sucesso!");
            return "ficticio"; //"form"
        } catch (RuntimeException e){
            ra.addFlashAttribute("error", "Não foi possível adicionar a área!");
            return "redirect:/ficticio";
            /* Maneira que encontrei para burlar o problema de não mostrar o erro pelo
            Binding Results
            */
        }
    }

    @DeleteMapping("/removerArea")
    public String removerArea(@RequestParam("id_area") long id_area, @RequestParam("id_prof") long id_prof, RedirectAttributes ra) {
        try {
            profService.removerAreaProfessor(id_prof, id_area);
            ra.addFlashAttribute("mensagem", "Área removida com sucesso!");
            return "ficticio"; //"form"

        } catch (RuntimeException e){
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/ficticio";
            /* Maneira que encontrei para burlar o problema de não mostrar o erro pelo
            Binding Results
            */
        }
    }

    @GetMapping("/listar/professor/areas/{id_prof}")
    public String listarAreasDoProfessor(@PathVariable("id_prof") long id_prof, Model model){
        model.addAttribute("professorAreas", profService.listarAreasPorProfessor(id_prof));
        return "pageFictícia";
    }

    @GetMapping("/listar/areas/professores/{id_area}") //Como que o front vai ter acesso a isso?
    public String listarProfsPorArea(@PathVariable("id_area") long id_area, Model model){
        model.addAttribute("profQuizzes", profService.listarProfessoresPorArea(id_area));
        return "pageFictícia";
    }

    @GetMapping("/listar/quizzes/{id_prof}")
    public String listarQuizzesCriados(@PathVariable("id_prof") long id_prof, Model model, RedirectAttributes ra){
        try {
            model.addAttribute("profQuizzes", quizService.listarQuizzesDoProfessor(id_prof));
            return "ficticio"; //"form"

        } catch (RuntimeException e){
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/ficticio";
            /* Maneira que encontrei para burlar o problema de não mostrar o erro pelo
            Binding Results
            */
        }
    }
}
