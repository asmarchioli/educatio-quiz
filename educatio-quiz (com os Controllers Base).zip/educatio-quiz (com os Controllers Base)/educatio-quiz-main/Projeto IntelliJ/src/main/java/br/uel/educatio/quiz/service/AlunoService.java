package br.uel.educatio.quiz.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.uel.educatio.quiz.dao.AlunoDAO;
import br.uel.educatio.quiz.dao.QuizDAO;
import br.uel.educatio.quiz.dao.RespostaDAO;
import br.uel.educatio.quiz.model.Quiz;
import br.uel.educatio.quiz.model.Resposta;

@Service
public class AlunoService {
    private final AlunoDAO alunoDAO;
    private final QuizDAO quizDAO;
    private final RespostaDAO respostaDAO;

    public AlunoService(AlunoDAO alunoDao, QuizDAO quizDAO, RespostaDAO respostaDAO) {
        this.alunoDAO = alunoDao;
        this.quizDAO = quizDAO;
        this.respostaDAO = respostaDAO;
    }

    public List<Quiz> buscarHistoricoQuizzes(long id_aluno) {
        return quizDAO.findQuizzesFeitos(id_aluno);

    }
    public List<Resposta> buscarRespostasQuiz(long id_aluno, long id_quiz) {
        return respostaDAO.findByIdAlunoAndIdQuiz(id_aluno, id_quiz);
    }
}
