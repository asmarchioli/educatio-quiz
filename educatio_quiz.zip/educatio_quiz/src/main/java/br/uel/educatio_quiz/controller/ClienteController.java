package br.uel.educatio_quiz.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.uel.educatio_quiz.model.Cliente;
import br.uel.educatio_quiz.service.ClienteService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/clientes")
public class ClienteController {
    private final ClienteService clienteService;

    @Autowired
    public ClienteController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping
    public String listar(HttpSession session, Model model) {
        String nome = (String) session.getAttribute("filtro");

        List<Cliente> clientes;
        if (nome != null && !nome.isEmpty()) {
            clientes = clienteService.buscarPorNome(nome);
        } else {
            clientes = clienteService.listarClientes();
        }

        model.addAttribute("clientes", clientes);
        return "clientes/lista_bootstrap";
    }

    @PostMapping("/filtro")
    public String aplicarFiltro(@RequestParam String nome, HttpSession session) {
        session.setAttribute("filtro", nome);
        return "redirect:/clientes";
    }

    @GetMapping("/limpar")
    public String limparFiltro(HttpSession session) {
        session.invalidate();
        return "redirect:/clientes";
    }

    @GetMapping("/novo")
    public String abrirCadastro(Model model) {
        model.addAttribute("cliente", new Cliente());
        return "clientes/form_bootstrap";
    }

    @PostMapping
    public String cadastrar(@Valid @ModelAttribute Cliente cliente,
                            BindingResult erros,
                            RedirectAttributes ra) {
        if (erros.hasErrors()) {
            return "clientes/form_bootstrap";
        }
        try {
            clienteService.cadastrarCliente(cliente);
            ra.addFlashAttribute("success", "Cliente cadastrado!");
            return "redirect:/clientes";
        } catch (DataIntegrityViolationException e) {
            erros.rejectValue("email", "cliente.email.duplicado", "E-mail já cadastrado.");
            return "clientes/form_bootstrap";
        }
    }

    @GetMapping("/editar/{id}")
    public String abrirEdicao(@PathVariable Long id, Model model, RedirectAttributes ra) {
        try {
            model.addAttribute("cliente", clienteService.buscarCliente(id));
            return "clientes/form_bootstrap";
        } catch (RuntimeException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/clientes";
        }
    }

    @PutMapping("/{id}")
    public String atualizar(@PathVariable Long id,
                            @Valid @ModelAttribute Cliente cliente,
                            BindingResult erros,
                            RedirectAttributes ra) {
        if (erros.hasErrors()) {
            return "clientes/form_bootstrap";
        }
        try {
            clienteService.atualizarCliente(id, cliente);
            ra.addFlashAttribute("success", "Cliente atualizado!");
            return "redirect:/clientes";
        } catch (DataIntegrityViolationException e) {
            erros.rejectValue("email", "cliente.email.duplicado", "E-mail já cadastrado.");
            return "clientes/form_bootstrap";
        } catch (RuntimeException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/clientes";
        }
    }

    @DeleteMapping("/{id}")
    public String excluir(@PathVariable Long id,
                          RedirectAttributes ra) {
        try {
            clienteService.excluirCliente(id);
            ra.addFlashAttribute("success", "Cliente excluído!");
        } catch (RuntimeException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/clientes";
    }
}
