package br.uel.educatio_quiz.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import br.uel.educatio_quiz.model.Cliente;

public interface ClienteRepository
        extends JpaRepository<Cliente, Long> {
    List<Cliente> findByNomeContainingIgnoreCase(String nome, Sort sort);
}
