package br.uel.educatio.quiz.service;


import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import br.uel.educatio.quiz.dao.QuestaoDAO;
import br.uel.educatio.quiz.model.Questao;
import jakarta.transaction.Transactional;


@Service
public class QuestaoService {
    private final QuestaoDAO questaoDAO;

    public QuestaoService(QuestaoDAO questaoDao) {
        this.questaoDAO = questaoDao;
    }

    @Transactional
    public List<Questao> listarQuestoesPorProf(long idProfessor) {
        return questaoDAO.findByProfessorId(idProfessor);
    }
    
    @Transactional
    public List<Questao> listarQuestoes() {
        return questaoDAO.findAll();
    }

    @Transactional
    public Questao buscarQuestao(long id_questao) {
        Optional<Questao> questaoOpt = questaoDAO.findById(id_questao);
        if (questaoOpt.isEmpty()) {
            throw new RuntimeException("Questão não encontrada");
        }
        
        Questao questao = questaoOpt.get();
        return questao;
    }

}

