package br.uel.educatio.quiz.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import br.uel.educatio.quiz.dao.QuizDAO;
import br.uel.educatio.quiz.model.Quiz;
import jakarta.transaction.Transactional;

@Service
public class QuizService {
    private final QuizDAO quizDAO;

    public QuizService(QuizDAO quizDao) {
        this.quizDAO = quizDao;
    }

    @Transactional
    public List<Quiz> listarQuizzesDoProfessor(long id_professor) {
        List<Quiz> quizzes = quizDAO.findByProfessorCriador(id_professor);
        if (quizzes.isEmpty()) {
             throw new RuntimeException("Professor não criou nenhum quiz ainda!");
         }
         return quizzes;
    }

    @Transactional
    public List<String> listarQuizAreas(long id_quiz){
        return quizDAO.findAreasQuiz(id_quiz);
    }

    @Transactional
    public List<Quiz> listarTodos(){
        return quizDAO.findAll();
    }

    @Transactional
    public void deletar(long id){
        quizDAO.deleteById(id);
    }

    @Transactional
    public Quiz buscarPorPin(String pin){
        Optional<Quiz> quizOpt = quizDAO.findByPinAcesso(pin);
        if (quizOpt.isEmpty()) {
            throw new RuntimeException("Quiz não encontrado!");
        }

        return quizOpt.get();
    }

    @Transactional
    public Quiz buscarPorId(long id){
        Optional<Quiz> quizOpt = quizDAO.findById(id);
        if (quizOpt.isEmpty()) {
            throw new RuntimeException("Quiz não encontrado!");
        }

        return quizOpt.get();
    }

    @Transactional
    public List<Quiz> buscarPorProfessorCriador(long id_prof){
        List<Quiz> quiz = quizDAO.findByProfessorCriador(id_prof);
        if (quiz.isEmpty()) {
            throw new RuntimeException("Quiz não encontrado!");
        }

        return quiz;    
    }

    @Transactional
    public void criar(Quiz quiz) throws RuntimeException {
        quizDAO.save(quiz);
    }
}