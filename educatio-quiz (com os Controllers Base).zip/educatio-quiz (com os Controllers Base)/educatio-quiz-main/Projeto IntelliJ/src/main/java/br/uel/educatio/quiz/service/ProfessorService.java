package br.uel.educatio.quiz.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.uel.educatio.quiz.dao.ProfessorAreaDAO;
import br.uel.educatio.quiz.dao.ProfessorDAO;
import br.uel.educatio.quiz.model.Professor; // Modificar múltiplos dados

@Service
public class ProfessorService {

    private final ProfessorDAO professorDAO;
    private final ProfessorAreaDAO professorAreaDAO;
    
    private final QuestaoService questaoService;

    public ProfessorService(ProfessorDAO professorDAO, ProfessorAreaDAO professorAreaDAO, QuizService quizService, QuestaoService questaoService) {
        this.professorDAO = professorDAO;
        this.professorAreaDAO = professorAreaDAO;
        this.questaoService = questaoService;
    }

    public List<Professor> listarTodos() {
        return professorDAO.findAll();
    }

    public Optional<Professor> buscarPorId(long id) {
        return professorDAO.findById(id);
    }

    @Transactional // Garante que a operação seja atômica (ou seja, se houver duas funções que alterem o banco, e uma delas não funcionar, o que a outra será desfeito)
    public Professor salvar(Professor professor) throws RuntimeException {
        // Validação de e-mail único (considerar mover para AuthService se houver AlunoDAO)
        Optional<Professor> existente = professorDAO.findByEmail(professor.getEmail());
        if (existente.isPresent() && existente.get().getId_professor() != professor.getId_professor()) {
            throw new RuntimeException("E-mail já cadastrado para outro professor.");
        }

        return professorDAO.save(professor);
    }

    @Transactional
    public Professor atualizarPerfilProfessor(long idProfessor, Professor professorAtualizado) throws RuntimeException {
        Optional<Professor> professorOpt = professorDAO.findById(idProfessor);
        if (professorOpt.isEmpty()) {
            throw new RuntimeException("Professor não encontrado para atualização.");
        }

        Professor professorExistente = professorOpt.get();

        professorExistente.setNome(professorAtualizado.getNome());
        professorExistente.setInstituicao_ensino(professorAtualizado.getInstituicao_ensino());
        professorExistente.setDescricao_profissional(professorAtualizado.getDescricao_profissional());
        professorExistente.setLattes(professorAtualizado.getLattes());

        if (!professorExistente.getEmail().equalsIgnoreCase(professorAtualizado.getEmail())) {
            Optional<Professor> emailExistente = professorDAO.findByEmail(professorAtualizado.getEmail());
            if (emailExistente.isPresent()) {
                throw new RuntimeException("Novo e-mail já está em uso por outro professor.");
            }
            professorExistente.setEmail(professorAtualizado.getEmail());
        }

        return professorDAO.save(professorExistente);
    }

    @Transactional
    public void deletarPorId(long id) throws RuntimeException {
        if (!professorDAO.existsById(id)) {
            throw new RuntimeException("Professor não encontrado para exclusão.");
        }
        // TODO: Adicionar lógica para verificar dependências (quizzes, questões) antes de excluir.
        // Exemplo: if (quizDAO.countByProfessor(id) > 0) throw new RuntimeException("Não pode excluir...");

        // Remove associações de área antes de deletar o professor
        professorAreaDAO.removeAllAreasFromProfessor(id);
        professorDAO.deleteById(id);
    }

    public boolean existePorId(long id) {
        return professorDAO.existsById(id);
    }

    // --- Métodos de Gerenciamento de Áreas ---

    @Transactional
    public void adicionarAreaProfessor(long idArea, long idProfessor) throws RuntimeException{
        // if (!professorDAO.existsById(idProfessor)) throw new RuntimeException("Professor não existe");
        // if (!areaDAO.existsById(idArea)) throw new RuntimeException("Área não existe");
        professorAreaDAO.addAreaToProfessor(idProfessor, idArea);
    }

    @Transactional
    public void removerAreaProfessor(long idProfessor, long idArea) {
        professorAreaDAO.removeAreaFromProfessor(idProfessor, idArea);
    }


    public List<String> listarAreasPorProfessor(long idProfessor) {
        List<String> areas = professorAreaDAO.findAreasByProfessorId(idProfessor);
        return areas;
    }


    public List<Professor> listarProfessoresPorArea(long idArea) {
        List<Long> idsProfessores = professorAreaDAO.findProfessorIdsByAreaId(idArea);
        // Busca os objetos Professor completos a partir dos IDs
        return professorDAO.findAllById(idsProfessores);
    }

}