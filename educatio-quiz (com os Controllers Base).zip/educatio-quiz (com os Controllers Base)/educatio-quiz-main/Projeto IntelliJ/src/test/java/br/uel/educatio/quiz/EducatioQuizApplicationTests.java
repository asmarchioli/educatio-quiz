package br.uel.educatio.quiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducatioQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
