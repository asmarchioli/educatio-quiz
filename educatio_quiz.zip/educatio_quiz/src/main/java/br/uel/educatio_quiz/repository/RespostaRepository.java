package br.uel.educatio_quiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.uel.educatio_quiz.model.Resposta;

public interface RespostaRepository extends JpaRepository<Resposta, Long> {
    Resposta findByEmailAndSenha(String email, String senha);
}
