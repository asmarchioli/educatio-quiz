package br.uel.educatio_quiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducatioQuizApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducatioQuizApplication.class, args);
	}

}
