package br.uel.educatio.quiz.controller;


import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import br.uel.educatio.quiz.service.AlunoService;


@Service
public class AlunoController {
    private final AlunoService service;

    public AlunoController(AlunoService alunoService) {
        this.service = alunoService;
    }

    @GetMapping("/buscarQuizzes")
    public String BuscarHistoricoQuizzes(Long id_aluno, Model model){
        model.addAttribute("historicoQuizzes", service.buscarHistoricoQuizzes(id_aluno));
        return "pageFicticia";
    }

    @GetMapping("/historicoQuiz")
    public String BuscarRespostasQuiz(@RequestParam("id_aluno") long id_aluno, @RequestParam("id_quiz") long id_quiz, Model model){
        model.addAttribute("historicoQuizzes", service.buscarRespostasQuiz(id_aluno, id_quiz));
        return "pageFicticia";
    }
}
