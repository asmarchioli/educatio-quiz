package br.uel.educatio.quiz.dao;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import br.uel.educatio.quiz.model.Quiz;
import br.uel.educatio.quiz.model.enums.Escolaridade;
import br.uel.educatio.quiz.model.enums.Exibicao;

@Repository
public class QuizDAO {

    private final JdbcTemplate jdbcTemplate;

    public QuizDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Quiz> rowMapper = (rs, rowNum) -> {
        Quiz quiz = new Quiz();
        quiz.setId_quiz(rs.getLong("id_quiz"));
        quiz.setTitulo(rs.getString("titulo"));
        quiz.setPin_acesso(rs.getString("pin_acesso"));
        quiz.setDescricao(rs.getString("descricao"));
        quiz.setVisibilidade(Exibicao.fromString(rs.getString("visibilidade")));
        quiz.setNivel_educacional(Escolaridade.fromString(rs.getString("nivel_educacional")));
        quiz.setProfessor_criador(rs.getLong("professor_criador"));
        quiz.setArea(rs.getLong("area"));
        Date dataCriacaoSql = rs.getDate("data_criacao");
        if (dataCriacaoSql != null) {
            quiz.setData_criacao(dataCriacaoSql.toLocalDate());
        }
        return quiz;
    };

    public List<Quiz> findAll() {
        String sql = "SELECT * FROM quiz ORDER BY titulo";
        return jdbcTemplate.query(sql, rowMapper);
    }

    public Optional<Quiz> findById(long id) {
        String sql = "SELECT * FROM quiz WHERE id_quiz = ?";
        try {
            Quiz quiz = jdbcTemplate.queryForObject(sql, new Object[]{id}, rowMapper);
            return Optional.ofNullable(quiz);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public Quiz save(Quiz quiz) {
        if (quiz.getId_quiz() == 0) {
            // INSERIR
            String sql = "INSERT INTO quiz (titulo, pin_acesso, descricao, visibilidade, nivel_educacional," +
                    "professor_criador, area, data_criacao) VALUES" +
                    "(?, ?, ?, CAST(? AS EXIBICAO), CAST(? AS ESCOLARIDADE), ?, ?, ?) RETURNING id_quiz";
            Long newId = jdbcTemplate.queryForObject(sql, new Object[]{
                    quiz.getTitulo(),
                    quiz.getPin_acesso(),
                    quiz.getDescricao(),
                    quiz.getVisibilidade().getDisplayValue(),
                    quiz.getNivel_educacional().getDisplayValue(),
                    quiz.getProfessor_criador(),
                    quiz.getArea(),
                    quiz.getData_criacao()
            }, Long.class);
            quiz.setId_quiz(newId != null ? newId : 0L);
        } else {
            // ATUALIZAR
            String sql = "UPDATE quiz SET titulo = ?, pin_acesso = ?, descricao = ?," +
                    "visibilidade = CAST(? AS EXIBICAO),nivel_educacional = CAST(? AS ESCOLARIDADE)," +
                    "professor_criador = ?, area = ?, data_criacao = ? WHERE id_quiz = ?";
            jdbcTemplate.update(sql,
                    quiz.getTitulo(),
                    quiz.getPin_acesso(),
                    quiz.getDescricao(),
                    quiz.getVisibilidade().getDisplayValue(),
                    quiz.getNivel_educacional().getDisplayValue(),
                    quiz.getProfessor_criador(),
                    quiz.getArea(),
                    quiz.getData_criacao(),
                    quiz.getId_quiz());
        }
        return quiz;
    }

    public void deleteById(long id) {
        String sql = "DELETE FROM quiz WHERE id_quiz = ?";
        jdbcTemplate.update(sql, id);
    }

    public boolean existsById(long id) {
        String sql = "SELECT COUNT(*) FROM quiz WHERE id_quiz = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, new Object[]{id});
        return count != null && count > 0;
    }


    public Optional<Quiz> findByPinAcesso(String pin) {
        String sql = "SELECT * FROM quiz WHERE pin_acesso = ?";
        try {
            Quiz quiz = jdbcTemplate.queryForObject(sql, rowMapper, new Object[]{pin});
            return Optional.ofNullable(quiz);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public List<Quiz> findByProfessorCriador(long professorId) {
        String sql = "SELECT * FROM quiz WHERE professor_criador = ? ORDER BY data_criacao DESC";
        return jdbcTemplate.query(sql, rowMapper, new Object[]{professorId});
    }

    /**
     * Busca todos os Quizzes que o aluno com o idAluno especificado respondeu.
     * @param idAluno ID do aluno
     * @return Lista de Quizzes realizados pelo aluno.
     */
    public List<Quiz> findQuizzesFeitos(long idAluno) {

        // 1. O SQL usa SELECT DISTINCT para listar o Quiz apenas uma vez,
        //    mesmo que o aluno tenha respondido várias questões dele.
        // 2. Assumimos o nome da tabela como 'TB_RESPOSTA'. Confirme este nome no seu banco.
        String sql = "SELECT DISTINCT q.* FROM TB_QUIZ q " +
                "JOIN TB_RESPOSTA r ON q.id_quiz = r.id_quiz " +
                "WHERE r.id_aluno = ?";

        // 3. Executa a query, mapeando os resultados da tabela TB_QUIZ para o objeto Quiz
        return jdbcTemplate.query(sql, rowMapper, new Object[]{idAluno});
    }
    
    public List<String> findAreasQuiz(long id_quiz){
        String sql = "Select nome_area from area a " +
                  "JOIN quiz q ON a.id_area = q.area " +
                  "WHERE q.id_quiz = ?";
                
        return jdbcTemplate.queryForList(sql, String.class, new Object[]{id_quiz});
        //Tem que colocar o tipo em segunda posição
    }
}